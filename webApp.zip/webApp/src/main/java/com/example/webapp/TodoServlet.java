package com.example.webapp;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "todoServlet", urlPatterns = "/todo-servlet")
public class TodoServlet extends HttpServlet {
    private TodoListService todoListService;

    @Override
    public void init() {
        todoListService = new TodoListService();
    }

    @Override
    public void destroy() {
        todoListService.close();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect("todo.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String action = request.getParameter("action");
        if (action != null) {
            switch (action) {
                case "add":
                    response.sendRedirect("addTask.jsp");
                    break;
                case "delete":
                    response.sendRedirect("deleteTask.jsp");
                    break;
                default:
                    response.sendRedirect("index.jsp");
                    break;
            }
        } else {
            response.sendRedirect("index.jsp");
        }
    }
}
