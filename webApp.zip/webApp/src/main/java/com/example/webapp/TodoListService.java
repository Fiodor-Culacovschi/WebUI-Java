package com.example.webapp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TodoListService {
    private static final String URL = "jdbc:mysql://localhost:3306/todoList";
    private static final String USER = "root";
    private static final String PASSWORD = "Database123";

    public TodoListService() {
        // Create database and table if they don't exist
        DatabaseUtil.createDatabase();
        DatabaseUtil.createTable();
    }

    public void close() {
        // Database connection closing
    }

    public void addItem(String task) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement("INSERT INTO todo_items (description) VALUES (?)")) {
            statement.setString(1, task);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteItem(long id) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement("DELETE FROM todo_items WHERE id = ?")) {
            statement.setLong(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<TodoItem> getAllItems() {
        List<TodoItem> todoItems = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM todo_items")) {
            while (resultSet.next()) {
                long id = resultSet.getLong("id");
                String description = resultSet.getString("description");
                todoItems.add(new TodoItem(id, description));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return todoItems;
    }
}
